1. Run run.m
