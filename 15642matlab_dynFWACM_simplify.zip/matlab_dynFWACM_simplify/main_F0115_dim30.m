%%
% Author: Chao Yu
%  Email: yuchao_1988@126.com

%%
clear;clc;
format long;

% Dimension is set as 30
FunctionDimArray = ones(1,15)*30;
% Repeat times as 51
Reptime = 51;

ParamsFunc.FunctionEvaluations = FunctionDimArray(1) * 10000;
ParamsFunc.FitnessSaveModStep  = 100;
ParamsFunc.FitnessMaxEvaMod100 = ParamsFunc.FunctionEvaluations/ParamsFunc.FitnessSaveModStep;

for func_id = 1 : 15   
    ParamsFunc.Dim = FunctionDimArray(func_id);
    ParamsFunc.FuncId = func_id;
    ParamsFunc.LowerBound   = -100;        
    ParamsFunc.UpperBound   =  100;      
    ParamsFunc.LowerInit    = -100;          
    ParamsFunc.UpperInit    =  100;
    ParamsFunc.FevalName = 'cec15_func';
    
    switch func_id
        case {1, 6, 15}
            ParamsFunc.Upper = 1.11; ParamsFunc.Lower = 0.80; 
        case {2, 3, 12}
            ParamsFunc.Upper = 1.18; ParamsFunc.Lower = 0.85;
        case {4, 5, 7, 9, 13}
            ParamsFunc.Upper = 1.25; ParamsFunc.Lower = 0.90; 
        case 8            
            ParamsFunc.Upper = 1.11; ParamsFunc.Lower = 0.90; 
        case 10
            ParamsFunc.Upper = 1.25; ParamsFunc.Lower = 0.85; 
        case {11, 14}
            ParamsFunc.Upper = 1.18; ParamsFunc.Lower = 0.90;           
        otherwise
            printf('SWITCH ERROR!');
    end
    
    % save file
    FileSaveFolder  = '.\resultfinal\';
    if ~isdir(FileSaveFolder) 
        mkdir(FileSaveFolder);
    end
    FitnessASFWA    = zeros(Reptime, ParamsFunc.FitnessMaxEvaMod100);
    TimeASFWA = zeros(1,Reptime);    
    txt_17_51 = zeros(17, Reptime);
    fprintf('\n FunctionId is %d, dim %d',ParamsFunc.FuncId,ParamsFunc.Dim);
    for runtime = 1:Reptime
        [FitnessASFWA(runtime,:), TimeASFWA(runtime), ExplosionAmplitude, txt_17_51(:, runtime)] = ASFWAFrameworkFWA(ParamsFunc);
    end

    % 15 * 5 tables
    fid_table = fopen([FileSaveFolder num2str(ParamsFunc.Dim) 'D_15_5.csv'], 'a');
    table_record = FitnessASFWA(:, size(FitnessASFWA, 2));
    fprintf(fid_table, '%e, %e, %e, %e, %e\n', ...
        min(table_record), max(table_record), median(table_record), ...
        mean(table_record), std(table_record));
    fclose(fid_table);
  
    % 17 * 51 matrices
    fid_file = fopen([FileSaveFolder 'dynFWACM_' num2str(func_id) '_' num2str(ParamsFunc.Dim) '.txt'], 'w');
    for fes = 1 : 17
        for runtime = 1 : Reptime
            fprintf(fid_file, '%e\t', txt_17_51(fes, runtime));
        end
        fprintf(fid_file, '\n');
    end
    fclose(fid_file);

end