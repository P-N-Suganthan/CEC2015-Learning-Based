/*
  CEC15 Test Function Suite for Single Objective Optimization
  B. Zheng (email: zheng.b1988@gmail.com) 
  Nov. 20th 2014
*/


testfunc.java is the test function
Example:
testfunc tf = new testfunc();

tf.test_func(x, f, dimension,population_size,func_num);

testmain.java is an example function about how to use testfunc.java