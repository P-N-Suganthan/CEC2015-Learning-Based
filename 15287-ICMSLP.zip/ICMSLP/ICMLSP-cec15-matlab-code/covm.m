function [B,D] = covm(a,center)
         dis           = sum((a-repmat(mean(a,2),1,size(a,2))).^2);
         [val,loc]     = sort(dis);
         b             = a(:,loc(1:0.6*size(a,2)));
         artmp   = (b-repmat(mean(b,2),1,size(b,2))); 
         C       = artmp * artmp'/(size(b,2)-1);         
         C       = triu(C) + triu(C,1)';    
         [B,D]   = eig(C);  
         % limit condition of C to 1e6 + 1
         if max(diag(D)) > 1e6*min(diag(D))
              tmp    = max(diag(D))/1e6 - min(diag(D));
               C     = C + tmp*eye(size(center,1));
              [B, D] = eig(C);
         end 
        D       = sqrt(diag(D));
end