clear all;
clc;
g        = sprintf('\n please input the dimension:');
D        = input(g);
if (D~=10&&D~=30&&D~=50&&D~=100)
    error('wrong dimension');
end
switch D
    case 10      
        pop_size = 40;
        apopsize = 700;
    case 30       
        pop_size = 50;
        apopsize = 1000;
    case 50       
        pop_size = 60;
        apopsize = 1200;
    case 100        
        pop_size = 70;
        apopsize = 2000;
end
Xmin=-100;
Xmax=100;
runs=51; 
fhd=str2func('cec15_func');
for i=13:15
    func_num=i;
    for j=1:runs        
        i        
        [gbest,gbestval,FES,t]= CR_func(fhd,D,pop_size,apopsize,Xmin,Xmax,func_num); 
         cy(i,j)=gbestval-func_num*100; 
         gbestval-func_num*100
         T(:,j)=t;        
    end 
    name     = strcat('CMLSP_',num2str(func_num),'_',num2str(D),'.txt'); 
    write(T,name);
end    
    