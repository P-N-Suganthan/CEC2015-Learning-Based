function cld_x = multivrandn(cent_x,B,D,xbmin,xbmax,sigma)
          d            = length(cent_x);
          cld_x        = cent_x + sigma*B * (D .* randn(d,1)); 
          idx_1        = cld_x<xbmin;
          idx_2        = cld_x>xbmax;
          if sum(idx_1)>0
              cld_x(idx_1) = min(xbmax,max(xbmin,2*xbmin-cld_x(idx_1)));
          end
          if sum(idx_2)>0
             cld_x(idx_2) = max(xbmin,min(xbmax,2*xbmax-cld_x(idx_2))); 
          end
%           temp_1       = rand(d,1);
%           cld_x(idx_1) = xbmin+temp_1(idx_1)*(xbmax-xbmin);
%           temp_2       = rand(d,1);
%           cld_x(idx_2) = xbmin+temp_2(idx_2)*(xbmax-xbmin);
%     dim_x   = size(cent_x,1);
%     pmuta   = 1/dim_x;
%     %crossover
%     cent_x  = B*cent_x;
%     cld_x   = cent_x;
%     cro_x   = B*x;
%     ncro    = min(floor(2*rand*dim_x)+1,dim_x);
%     loc_cro = randperm(dim_x);
%     loc     = loc_cro(1:ncro);
%     cld_x(loc_cro(ncro+1:dim_x)) = cro_x(loc_cro(ncro+1:dim_x));
%     r       = 1-rand^sigma;
%     rc      = 0.5*rand*r*(rand(ncro,1)+rand); 
%     %rc = r*rand(ncro,1);
%     if rand<0.5
%         cld_x(loc) = cent_x(loc)+rc.*(cent_x(loc)-cro_x(loc));
%         cld_x(loc) = min(max(cld_x(loc),xbmin(loc)),xbmax(loc));
%     else
%         cld_x(loc) = cent_x(loc)-rc.*(cent_x(loc)-cro_x(loc));
%     end
%     %mutation
%     loc_muta = find(rand(1,dim_x) <= pmuta);
%     len_muta = length(loc_muta);
%     for i = 1:len_muta
%         loc  = loc_muta(i);
%         yl   = xbmin(loc);
%         yu   = xbmax(loc);
%         y    = cld_x(loc);
%         rm   = r*(2*rand-1);
%         y    = y+rm*(yu-yl);
%         if y > yu
%             y = yu-rand*(yu-cld_x(loc));
%         elseif y < yl
%             y = yl+rand*(cld_x(loc)-yl);
%         end
%         cld_x(loc) = y;
%     end
%     cld_x=B'*cld_x;
         
end