function [val_x,val_f] = selection(total_x,total_f)
         [val,loc]     = sort(total_f);
          num_x        = size(total_x,2);
          val_x        = total_x(:,loc(1:num_x/2));
          val_f        = total_f(loc(1:num_x/2));        
            
end