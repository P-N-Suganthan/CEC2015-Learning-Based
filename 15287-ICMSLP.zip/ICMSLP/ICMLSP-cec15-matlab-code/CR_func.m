function [cent_x,cent_f,fitcount,t]= CR_func(fhd,Dimension,popsize,apopsize,VRmin,VRmax,func_num)
rand('state',sum(100*clock));
d  = Dimension;
if length(VRmin)==1
    xbmin = repmat(VRmin,d,popsize);
    xbmax = repmat(VRmax,d,popsize);
end
%%
P=0.5;
if rand<P
    sigma=0.60 + 0.1*tan(pi*(rand - 0.5));
    while any(sigma)<0||any(sigma)>1
    sigma=0.60 + 0.1*tan(pi*(rand - 0.5));
    end
else
    sigma =1 + 0.1*tan(pi*(rand - 0.5));
    while any(sigma)<0||any(sigma)>1
    sigma =1 + 0.1*tan(pi*(rand - 0.5));
    end
end
% %%  
val_x        =  xbmin+(xbmax-xbmin).*rand(d,popsize);
val_f        =  feval(fhd,val_x,func_num);
fitcount     =  popsize;
[val,loc]    =  sort(val_f);
cent_x       =  val_x(:,loc(1));
cent_f       =  val_f(1);
num          =  floor(popsize/2);
gen          =  fitcount/popsize;
maxgen       =  d*10000/popsize;
%%
sval_x       =  val_x(:,loc(1:num));
[B,D]        =  covm(sval_x,cent_x);
t=[];
  while fitcount<d*10000  
       stor_x = zeros(d,popsize);
       stor_f = zeros(1,popsize);        
%%        
           for k  = 1:popsize                 
                cld_x            = multivrandn(cent_x,B,D,VRmin,VRmax,sigma);
                cld_f            = feval(fhd,cld_x,func_num);
                fitcount         = fitcount+1;
                 if cld_f<cent_f  
                    stor_x(:,k)  = cent_x;
                    stor_f(k)    = cent_f;
                    cent_x       = cld_x;
                    cent_f       = cld_f;                    
                else
                    stor_x(:,k)  = cld_x;
                    stor_f(k)    = cld_f;                    
                end
               if fitcount >d*10000
                    return;
                elseif fitcount==100*d||fitcount==200*d||fitcount==300*d||fitcount==500*d...
                     ||fitcount==1000*d||fitcount==2000*d||fitcount==3000*d||fitcount==4000*d||fitcount==5000*d...
                     ||fitcount==6000*d||fitcount==7000*d||fitcount==8000*d||fitcount==9000*d||fitcount==10000*d
                     t=[t;cent_f-func_num*100];             
                end
           end     
%                    P=(gen-1)/maxgen;                                    
                  if rand<P
                            sigma=0.60 + 0.1*tan(pi*(rand - 0.5));
                      while sigma<0||sigma>1
                            sigma=0.60 + 0.1*tan(pi*(rand - 0.5));
                      end
                  else
                            sigma =1 + 0.1*tan(pi*(rand - 0.5));
                      while sigma<0||sigma>1
                            sigma =1 + 0.1*tan(pi*(rand - 0.5));
                      end
                  end                     
                       [val,loc]  = sort(stor_f);
                       val_x      = stor_x(:,loc(1:num));                        
                   if size(sval_x,2)<apopsize
                       sval_x     = [sval_x,val_x];
                   else                    
                       sval_x     = [sval_x(:,popsize+1:end),val_x]; 
                   end 
                      [B,D]      = covm(sval_x,cent_x);                          
%%
  end    
end
