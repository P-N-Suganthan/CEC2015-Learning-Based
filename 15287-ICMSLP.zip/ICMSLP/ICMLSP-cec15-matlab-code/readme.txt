1.This programe starts with file main.m 
2. If you have any question, please contact us: chenaction@126.com, hlliu@gdut.edu.cn.