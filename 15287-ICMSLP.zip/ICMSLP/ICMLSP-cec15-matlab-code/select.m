function [stor_x,stor_f] = select(val_x,stor_x,val_f,stor_f)
         num    = size(val_x,2);         
%        for i=1:num
%            if val_f(i)<stor_f(i)
%               stor_f(i)   = val_f(i);
%               stor_x(:,i) = val_x(:,i);
%            end
%        end
end