function [sval,sval_f]  = update(sval_x,sval_f,val_x,val_f)
            totval_x    = [sval_x,val_x];
            totval_f    = [sval_f,val_f];            
            [val,loc]   = sort(totval_f);
            sval        = totval_x(:,loc(1:size(sval_x,2)));
            sval_f      = totval_f(loc(1:size(sval_x,2)));