function [B,D]=covm1(a,b,center)    
    artmp = (1/1)*(a-repmat(center,1,size(a,2)));
    artmp1 = (1/1)*(b-repmat(center,1,size(b,2)));
    C     = 0.3*artmp * artmp'/(size(a,2))+0.7*artmp1 * artmp1'/(size(b,2));
    C     = triu(C) + triu(C,1)';    
    [B,D] = eig(C);   
   if max(diag(D)) > 1e20*min(diag(D))
      tmp = max(diag(D))/1e20 - min(diag(D));
       C = C + tmp*eye(size(center,1));
        [B, D] = eig(C);
   end 
      D            = sqrt(diag(D)); 
end