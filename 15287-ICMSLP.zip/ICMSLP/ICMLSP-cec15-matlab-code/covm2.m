function [B,D] = covm2(a,center)
%          dis           = sum((a-repmat(center,1,size(a,2))).^2);
%          [val,loc]     = sort(dis);
%          b             = a(:,loc(1:size(a,2)/2));
         b=a;
         artmp   = (b-repmat(mean(b,2),1,size(b,2))); 
         C       = artmp * artmp'/(size(b,2)-1);         
         C       = triu(C) + triu(C,1)';    
         [B,D]   = eig(C);   
         if any(diag(D)<0)
            disp('error')
         end         
         if max(diag(D)) > 1e10*min(diag(D))
              tmp    = max(diag(D))/1e10 - min(diag(D));
               C     = C + tmp*eye(size(center,1));
              [B, D] = eig(C);
         end 
        D       = sqrt(diag(D));
end