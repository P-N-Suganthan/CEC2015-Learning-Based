/*
    Copyright 2015 Dogan Aydin and Thomas Stuetzle
    
    Dogan Aydin		<dogan.aydin@dpu.edu.tr>
    Thomas Stuetzle	<stuetzle@ulb.ac.be>

    This file is part of ABC-X-LS.

    ABC-X-LS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    ABC-X-LS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ABC-X-LS.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CONFIGURATION_H
#define CONFIGURATION_H

#include <vector>
#include <cmath>

//CEC'15 problems
#define	R_HC_ELLIPTIC 		0
#define R_CIGAR			1
#define SR_ACKLEY 		2
#define SR_RASTRIGIN		3
#define SR_SCHWEFEL 		4
#define HYBRID_1 		5
#define HYBRID_2 		6
#define HYBRID_3 		7
#define COMPOSITION_1 		8
#define COMPOSITION_2 		9
#define COMPOSITION_3 		10
#define COMPOSITION_4 		11
#define COMPOSITION_5 		12
#define COMPOSITION_6 		13
#define COMPOSITION_7 		14

//scout bee strategies
#define DEFAULT_SCOUT	1
#define BABC_SCOUT	2
#define CABC_SCOUT	3
#define IABC_SCOUT	4
#define ERABC_SCOUT	5

//probability calculation strategies
#define DEFAULT_PROBCALC	1
#define WEIGHTED_PROBCALC	2
#define ORDERED_PROBCALC	3

//initialization strategies
#define DEFAULT_INIT	1
#define CHAOTIC_INIT	2


	
// Chaotic Maps
#define LOGISTIC	1
#define CIRCLE		2
#define GAUSS		3
#define SINUSOIDAL	4
#define SINUS		5
#define TEND		6
#define HENON		7
#define ACFUNC		8


//local search algorithms
#define 	NO_LOCAL_SEARCH		0
#define     	MTSLS1          	1
#define		POWELL			2
#define		CMAES			3
#define		ADAPTIVE_LS		4

//random number generation range
#define DEFAULT_RAND	0
#define	NOTDEFAULT_RAND	1

//types of Local Search Invocation Strategies
#define		DEFAULT_LS_STRATEGY	1
#define		ILS_STRATEGY		2

// terms of Search equations (2., 3., and 4. terms)
#define GBEST_CURRENT 	1
#define GBEST_RANDOM	2 
#define CURRENT_RANDOM	3
#define RANDOM_RANDOM	4
#define CURRENT_GBESTDIST 5
#define NO_STRATEGY	6
// (1. term)    
#define CURRENTLOC	1
#define RANDOMLOC	2
#define GBESTLOC	3

#define PI 3.1415926535897932384626433832795029

class Configuration {

      private:

	//general parameters
	unsigned long rngSeed;
	unsigned int maxFES;

	//problem parameters
	unsigned int problemID;
	unsigned int problemDimension;
	double minInitRange;
	double maxInitRange;
	
	//---------------------------------------------ABC PARAMETERS-------------------------------------------------
	// tum abc çeşitleri için ortak parametreler
	unsigned int numOfFoods;//yiyecek kaynağı (popülasyon) sayısı
	double limitF; // limit faktörü (limit=limitF*numOfFoods*problemDimension))
	
	// ILKLEME ILE ILGILI PARAMETRELER
	unsigned int initStr; // ilkleme uniform dagilima mi yoksa kaotik dagilima gore mi olacak
	bool isOppInit; // opposition-based bir ilkleme olacak mı
	unsigned int cmapID; // Kaotik map ID'si (7-8 tane kaotik map var.)
	unsigned int k_param; // kaotik iterasyon sayısı
	double mu; // bir kaotik map içerisinde geçen değişlen (0,1) arası değer alır.

	
	// EMPLOYED BEES VE ONLOOKER BEES ASAMALARI PARAMETRELERI
	//MR parametreleri için
	//MR'leri problemDimension ile bağlantılı yaptık. Dolayısıyla
	// aşağıdaki parametreler oran belirtiyor. (0,1) arası değer
	// alıyorlar. Bu değeri problemDimension ile çarptığımızda
	// MR değerlerini buluyoruz.
	int mre; // Employed bee aşamasındaki MR parametresi 
	int mro; // Onlooker bee için MR parametresi
	int mrer;
	int mror;
	unsigned int  dmre;
	unsigned int  dmro;
	// phi değeri original ABC'de (-1,1) arasında değişiyordu.
	// ama başka çeşitlerde farklılık gösterebiliyor.
	// buradaki değişkenler arama işlemindeki her terim için
	// phi aralığını (-1,1) mi yoksa başka türlü mü olabileceğini
	// belirliyor. parametreler 0 yada 1 değerini alıyor. Eğer 0 
	// değerini alırsa (-1,1) arasında değerler üretilir. 1 olursa
	// randHRange1e, randLRange1e gibi değişkenlerin belirlediği 
	// aralığa göre rastgele değerler alacaktır. Buradaki amacımız
	// default aralık olan (-1,1) mi iyi yoksa diğer yaklaşımlar mı görebilmek
	unsigned int drand1e;//empl. bee ikinci terim için aralık (-1,1) olsun mu?
	unsigned int drand2e;//empl. bee ucuncu terim için aralık (-1,1) olsun mu?
	unsigned int drand3e;//empl. bee dorduncu terim için aralık (-1,1) olsun mu?
	unsigned int drand1o;//onl. bee ikinci terim için aralık (-1,1) olsun mu?
	unsigned int drand2o;//onl. bee ucuncu terim için aralık (-1,1) olsun mu?
	unsigned int drand3o;//onl. bee dorduncu terim için aralık (-1,1) olsun mu?
	
	// onlooker bee ve employed aşamasındaki arama işlemindeki her bir terimin phi aralıklarını
	// belirlerler. U(-a1,a1) = U(-1*randRange1e,randRange1e) 
	double randRange1o;
	double randRange2o;
	double randRange3o;

	double randRange1e;
	double randRange2e;
	double randRange3e;
	
	// onl. ve emp. bees aşamalarındaki arama işlemindeki her bir terim ne olmalı
	// integer alınan değerlerden her biri bir terimi temsil ediyor.	
	unsigned int firstTermOnl;
	unsigned int secondTermOnl;
	unsigned int thirdTermOnl;	
	unsigned int fourthTermOnl;

	unsigned int firstTermEmp;
	unsigned int secondTermEmp;
	unsigned int thirdTermEmp;	
	unsigned int fourthTermEmp;
	
	//onlooker bee aşamasında her bir yiyecek kaynaginin olasılık hesabında kullanilacak
	//yontem tipi (probability calculation type)
	unsigned int pctype;
	double sp; // eger olasılık hesabı ORDERED_PROBCALC olursa hesaplamada geçen bir parametre
	
	// SCOUT BEE ASAMASI PARAMETRELERI
	unsigned int scoutStrID;//hangi scout bee stratejisi secilecek
	// wMax ve wMin parametreleri scout bee stratejisi BABC_SCOUT oldugunda kullanilan parametreler
	double wMax;
	double wMin;
	// scout bee statejisi IABC_SCOUT oldugunda kullanilan bir parametre
	double shakingFactor;// yeni konumlanacak yiyecek kaynaginin en iyiye ne kadar yakin olacaginin faktörü
	
	// YEREL ARAMA ILE ILGILI PARAMETRELER
	unsigned int lsIterations; // yerel arama algoritması iterasyon sayısı
	unsigned int lsEvals;
	double fTol; // FTOL parameteresi yerel arama algoritması Powell secildiğinde kullanilir. Hata esik degeri
	unsigned int lsID; // Hangi yerel arama algoritmasi kullanilacak. 0 = yerel arama kullanma
	double tr;
	
	unsigned int stepSizeType; // yerel arama algoritmalara ozgu adim buyuklugu parametresi. Tarıyacagi alanin genisligini belirler
	unsigned int maxFailures; // yerel arama ayni yiyecek kaynaginda defalarca basarisiz olabilir. Bu parametre bunun limit degerini
				  // belirler
	unsigned int lsStrategy; // yerel aramanin nasil uygulanacaginin stratejisi belirlenir
	//CMAES parametreleri
	double ttunea;
	double ttuneb;
	double ttunec;
	double ttuned;
	double ttunee;
	double ttunef;
	double ttuneg;

	
	//POPULASYON SAYISININ ARTIRILMASINA OZGU PARAMETRELER
	bool isIncrementedPop; // populasyon sayisi artacak mi?
	unsigned int maxFoodSize; // artacaksa kaca kadar artacak
 	unsigned int growthPeriod; // kac iterasyonda bir artacak
	
	//Extra variables
	double startTime; // zamani tutmak ici


  public:

	Configuration(int argc,char** argv);
	~Configuration();

	unsigned long getRNGSeed();
	unsigned int getMaxFES();

	unsigned int getProblemID();
	
	unsigned int getProblemDimension();
	double getMinInitRange();
	double getMaxInitRange();

	double getMinInitBound();
	double getMaxInitBound();

	//paramaters for all ABC variants
	unsigned int numOfFoodSources();
	void setCurrentFoodSize(unsigned int newSize);
	
	unsigned int getLimit();

	// wMax and wMin parameters for best-so-far solution ABC
	double getWMax();
	double getWMin();

	unsigned int getMRE();
	unsigned int getMRO();
	
	unsigned int getK();
	double getMu();
	
	//improved ABC and Chaotic ABC
	unsigned int getChaoticMapID();
	
	double getSP();

	unsigned int getLSIterations();
	unsigned int getLSEvaluations(){return lsEvals;}
	double trainingRatio(){return tr;}
	unsigned int getLocalSearchID();
		
	unsigned int getMaximumFoodSize();
 	unsigned int getGrowthPeriod();
	
	//CMAES parametreleri
	double gettunea();
	double gettuneb();
	double gettunec();
	double gettuned();
	double gettunee();
	double gettunef();
	double gettuneg();
	

	double getShakingFactor();

	double getFTol();
	
	unsigned int getMaxRepeatedFailures();
	
	unsigned int getLSStrategy();
	
	unsigned int initStrategy(){return initStr;}
	unsigned int probabilityCalcType(){ return pctype;}
	unsigned int scoutBeeStrategy(){return scoutStrID;}

	bool isPopulationIncremented(){ return isIncrementedPop;}
	bool isOppositeInit(){return isOppInit;}  
	  
	bool isDefaultUniformRE1();
	bool isDefaultUniformRE2();
	bool isDefaultUniformRE3();
	bool isDefaultUniformRO1();
	bool isDefaultUniformRO2();
	bool isDefaultUniformRO3();
	
	double getRandRange1o(){return randRange1o;}
	double getRandRange2o(){return randRange2o;}
	double getRandRange3o(){return randRange3o;}

	double getRandRange1e(){return randRange1e;}
	double getRandRange2e(){return randRange2e;}
	double getRandRange3e(){return randRange3e;}
	
	unsigned int FirstTermStrategyOnl(){return firstTermOnl;}
	unsigned int SecondTermStrategyOnl(){return secondTermOnl;}
	unsigned int ThirdTermStrategyOnl(){return thirdTermOnl;}	
	unsigned int FourthTermStrategyOnl(){return fourthTermOnl;}

	unsigned int FirstTermStrategyEmp(){return firstTermEmp;}
	unsigned int SecondTermStrategyEmp(){return secondTermEmp;}
	unsigned int ThirdTermStrategyEmp(){return thirdTermEmp;}	
	unsigned int FourthTermStrategyEmp(){return fourthTermEmp;}
	
	void setStartTime(double stime);
	double getStartTime();

	void print();
};

#endif
