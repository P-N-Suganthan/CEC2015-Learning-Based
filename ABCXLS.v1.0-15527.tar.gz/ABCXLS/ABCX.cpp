/*
    Copyright 2015 Dogan Aydin and Thomas Stuetzle
    
    Dogan Aydin		<dogan.aydin@dpu.edu.tr>
    Thomas Stuetzle	<stuetzle@ulb.ac.be>

    This file is part of ABC-X-LS.

    ABC-X-LS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    ABC-X-LS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ABC-X-LS.  If not, see <http://www.gnu.org/licenses/>.
*/

#include	"foodSource.h"
#include	"ABC.h"
#include	"ABCX.h"
#include	"configuration.h"
#include	"rng.h"
#include	"problem.h"
#include	"mtsls1.h"
#include	"icmaesils.h"
#include	"localSearch.h"
#include	"chaoticmaps.h" 
#include	<cfloat> 
#include	<iostream>

/**********************************************************************************************************************
 * ABCX algoritmasının bulundugu sınıf
 * ********************************************************************************************************************/

//////////////////////////////////////////// CONSTRUCTOR AND DESTRUCTOR ////////////////////////////////////////////////
/**********************************************************************************************************
 * parametreler
 * ------------
 * conf: konfigurasyon nesnesi 
 * problem: problem nesnesi 
 * ls: yerel arama algoritmasi nesnesi
 * 
 * Yapılandırıcı içerisinde yiyecek kaynakları ilkleniyor ve her yiyecek kaynagina ait bilgiler ekleniyor 
 * ********************************************************************************************************/
ABCX::ABCX(Configuration * conf, Problem * problem, LocalSearch * ls): ABC(conf,problem, ls){
 
  initFoodSources();
  tempSource = new double[conf->getProblemDimension()];
  solution = new double[conf->getProblemDimension()];
  nols = false;
}

// destructor
ABCX::~ABCX(){

  delete [] tempSource;
  delete [] solution;
  int popsize= foodSources.size();
  for(unsigned int i=0;i<popsize;i++)
	  delete foodSources.at(i);
  foodSources.clear();

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////// INITIALIZATION STRATEGIES //////////////////////////////////////////////////

/*******************************************************************************************************************
 * yiyecek kaynaklarini olusturur. DEFAULT_INIT secilirse varsayılan sekilde rasgele dagilir. 
 * CHAOTIC_INIT secilirse kaotik rassal üreteclere gore yerlerine konumlandirilir.
 * Ayrıca istendiğinde opposition based ilkleme de olabilir.
 * 
 * Bu ilkleme mekanizmasi ile literatürdeki 4 ilkleme yöntemi birden elde edilmistir.
 * *****************************************************************************************************************/
void ABCX::initFoodSources(){
  switch(config->initStrategy()){
    case DEFAULT_INIT: initFoodSourcesDefault(); break;
    case CHAOTIC_INIT: initFoodSourcesChaotic(); break;
  }
  
  if(config->isOppositeInit())
    initFoodSourcesOpposition();
}

/******************************************************************************************************************
 * varsayilan ilkleme yapiliyor. Yiyecekler olusturularak foodSources adindaki vektore ekleniyor 
 * 
 * ***************************************************************************************************************/
void ABCX::initFoodSourcesDefault(){
  for(int i = 0; i < config->numOfFoodSources(); i++){
      FoodSource * newFoodSource = new FoodSource(config, p);
      foodSources.push_back(newFoodSource);
  }
}



/******************************************************************************************************************
 * kaotik ilkleme yapiliyor. Yiyecekler olusturularak foodSources adindaki vektore ekleniyor 
 * dikkat edilirse FoodSource sinifinin yapilandiricisi otekine gore farkli
 * ***************************************************************************************************************/
void ABCX::initFoodSourcesChaotic(){
  for(int i = 0; i < config->numOfFoodSources(); i++){
      FoodSource * newFoodSource = new FoodSource(config, p, config->getK());
      foodSources.push_back(newFoodSource);
  }  
}

/*****************************************************************************************************************
 * İki yiyecek kaynagi için karsilastirma sinifi. Objektif fonksiyon baz olınmış. Bunu kullanmamızın sebebi 
 * opposition-based ilkleme ile ilgili. Opposition based ilklemede her yiyecek kaynağının tersi alındıktan sonra
 * yiyecek kaynakları sıralanıyor ve en kötüler yok ediliyor. Sıralama işlemi hazır sort fonksiyonu ile yapılıyor
 * ve bu fonksiyon sıralanacak nesneler için bir karşılaştırma kriteri istediği için bu sınıf yazilmistir.
 * ***************************************************************************************************************/
class FSComparator{
  public:
    bool operator()(FoodSource * f1, FoodSource * f2){
	return f1->getObjectiveValue() < f2->getObjectiveValue();
    }
};

/****************************************************************************************************************
 * burada tüm yiyecek kaynaklarinin zıtlari alınarak yiyecek kaynaklarina ekleniyor. Daha sonra bu yiyecek kaynaklari
 * siralanip en kötü yarisi siliniyor
 * *************************************************************************************************************/
void ABCX::initFoodSourcesOpposition(){
  for(int i = 0; i < config->numOfFoodSources(); i++){
      FoodSource * aFoodSource = foodSources.at(i);
      FoodSource * oppositeFoodSource = new FoodSource(config, p, aFoodSource->getLocation());
      foodSources.push_back(oppositeFoodSource);		
  }
  
  //sort foodsources according to their fitness
  FSComparator fscomp;
  sort(foodSources.begin(), foodSources.end(), fscomp);
  //delete half of the worst food sources
  for (int i =config->numOfFoodSources(); i < config->numOfFoodSources()*2; i++)
    	  delete foodSources.at(i);
  foodSources.erase(foodSources.begin()+config->numOfFoodSources(), foodSources.end()); 
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////Search Equations////////////////////////////

/****************************************************************************************************************
 * fsource: komsulugu bulunacak yiyecek kaynagi
 * fID: komsuluk yiyecek kaynaginin indeksi
 * Bu metod uzakliga gore komsu secimi yapmak icin kullanilmaktadir. 
 * **************************************************************************************************************/
FoodSource * ABCX::getSuitableReferencefor(FoodSource * fsource, unsigned int fID){
    
    long double denum = 0.0;
    long double fProbs[foodSources.size()];
    
    // her bir yiyecek kaynaginin olasiligi hesaplaniyor
    // yiyecek kaynagina yakin olan yiyecek kaynaklarinin 
    // olasiligi daha yuksek oluyor
    for (unsigned int i=0;i<foodSources.size();i++) { 
	if (i != fID){
	    FoodSource * refFood = foodSources.at(i);
	    fProbs[i] = 1.0 / fsource->distanceTo(refFood);
	    denum += fProbs[i];
	}
    }
    
    double r = RNG::randVal(0,1);
    long double totalprobs = 0.0;
    unsigned int k = -1;
    
    // rulet benzeri bir secim ile olasilikli bir secim kurali ile bir yiyecek kaynagi seciliyor
    do{
	k++;
	if(k != fID){
	    totalprobs += fProbs[k];
	}
    }while(r * denum > totalprobs);
    
    return foodSources.at(k);
}

/******************************************************************************************************
 * index: referans yiyecek kaynağının indeksi
 * p2c: hangi parametrenin (boyutun) değişikliğe uğrayacağı
 * Employed bee aşamasindaki arama isleminin ilk teriminin belirlenmesi
 * 
 * ****************************************************************************************************/
double ABCX::getFirstTermEmp(int index, int p2c){
  // siradaki (index) yiyecek kaynagini al
  FoodSource * currentFood = foodSources.at(index);
  //bu yiyecek kaynaginin pozisyonunu al
  double * currloc = currentFood->getLocation();
  
  // rasgele bir komsunun pozisyonunu al. Bu komsu yiyecek kaynagi siradaki yiyecek kaynagindan (index) farklidir. 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  double * neighbourloc = (foodSources.at(neighbour))->getLocation();

  //global-best (en-iyi) yiyecek kaynaginin pozisyonunu al.
  double * gbestloc = (getBestFSource())->getLocation();
  
  // yukarida alinan pozisyonlardan hangisi seciliyorsa o pozisyonun
  // ilgili boyutu (p2c) dondurur.
  double value = 0;
  switch(config->FirstTermStrategyEmp()){
    case CURRENTLOC: value = currloc[p2c]; break;
    case RANDOMLOC: value = neighbourloc[p2c]; break;
    case GBESTLOC: value = gbestloc[p2c]; break;
  }
  
  return value;
}


double ABCX::getSecondTermEmp(int index, int p2c){
  // siradaki (index) yiyecek kaynagini al
  FoodSource * currentFood = foodSources.at(index);
  // bu yiyecek kaynaginin pozisyonunu al
  double * currloc = currentFood->getLocation();
 
  // rasgele bir komsunun pozisyonunu al. Bu komsu yiyecek kaynagi siradaki yiyecek kaynagindan (index) farklidir. 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  // rasgele diger bir komsunun pozisyonunu al. Bu komsu yiyecek kaynagi siradaki yiyecek kaynagindan (index)
  // ve diger rasgele yiyecek kaynagindan farklidir. 
  int neighbour2 = -1;
  do{
      neighbour2= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour2 == index || neighbour2 == neighbour);

  double * neighbourloc = (foodSources.at(neighbour))->getLocation();
  double * neighbour2loc = (foodSources.at(neighbour2))->getLocation();
  
  //global-best (en-iyi) yiyecek kaynaginin pozisyonunu al.
  double * gbestloc = (getBestFSource())->getLocation();
  
  //komsuluk uzakligina gore rasgele bir komsu pozisyonu al
  FoodSource * gbestneighbour = getSuitableReferencefor(currentFood, index);
  double * gbestdistloc = gbestneighbour->getLocation();

  double value = 0;
  
  double randlr= -1.0; // phi sayısının varsayilan alt limiti 
  double randhr= 1.0;  // phi sayisinin varsayilan ust limiti
  
  // eger varsayilan degerler secilmeyecekse yeni alt ve ust limitleri consoldan alinan
  // degerlere gore belirler
  if(!config->isDefaultUniformRE1()){
      randlr= -1.0*config->getRandRange1e();
      randhr= config->getRandRange1e();
  }
  
  // hangi strateji secilmisse o stratejiye uygun ikinci terim isletilip sonuc donduruluyor
  switch(config->SecondTermStrategyEmp()){
    case GBEST_CURRENT: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-currloc[p2c]); break;
    case GBEST_RANDOM: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-neighbourloc[p2c]); break;
    case CURRENT_RANDOM: value = RNG::randVal(randlr,randhr)*(currloc[p2c]-neighbourloc[p2c]); break;
    case RANDOM_RANDOM: value = RNG::randVal(randlr,randhr)*(neighbourloc[p2c]-neighbour2loc[p2c]); break;
    case CURRENT_GBESTDIST: value = RNG::randVal(randlr,randhr)*(currloc[p2c]- gbestdistloc[p2c]); break;
    case NO_STRATEGY: value = 0; break;
  }

  return value;
 
}
      
double ABCX::getThirdTermEmp(int index, int p2c){
   FoodSource * currentFood = foodSources.at(index);
  double * currloc = currentFood->getLocation();
  /*A randomly chosen solution is used in producing a mutant solution of the solution i*/ 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  int neighbour2 = -1;
  do{
      neighbour2= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour2 == index || neighbour2 == neighbour);

  double * neighbourloc = (foodSources.at(neighbour))->getLocation();
  double * neighbour2loc = (foodSources.at(neighbour2))->getLocation();
  
  double * gbestloc = (getBestFSource())->getLocation();
  
  FoodSource * gbestneighbour = getSuitableReferencefor(currentFood, index);
  double * gbestdistloc = gbestneighbour->getLocation();
  
  
  double value = 0;
  double randlr= -1.0;
  double randhr= 1.0;
  
  if(!config->isDefaultUniformRE2()){
      randlr= -1.0*config->getRandRange2e();
      randhr= config->getRandRange2e();
  }
  switch(config->ThirdTermStrategyEmp()){
    case GBEST_CURRENT: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-currloc[p2c]); break;
    case GBEST_RANDOM: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-neighbourloc[p2c]); break;
    case CURRENT_RANDOM: value = RNG::randVal(randlr,randhr)*(currloc[p2c]-neighbourloc[p2c]); break;
    case RANDOM_RANDOM: value = RNG::randVal(randlr,randhr)*(neighbourloc[p2c]-neighbour2loc[p2c]); break;
    case CURRENT_GBESTDIST: value = RNG::randVal(randlr,randhr)*(currloc[p2c]- gbestdistloc[p2c]); break;
    case NO_STRATEGY: value = 0; break;
  }
  
  return value;
}
      
      
double ABCX::getFourthTermEmp(int index, int p2c){
   FoodSource * currentFood = foodSources.at(index);
  double * currloc = currentFood->getLocation();
  /*A randomly chosen solution is used in producing a mutant solution of the solution i*/ 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  int neighbour2 = -1;
  do{
      neighbour2= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour2 == index || neighbour2 == neighbour);

  double * neighbourloc = (foodSources.at(neighbour))->getLocation();
  double * neighbour2loc = (foodSources.at(neighbour2))->getLocation();
  
  double * gbestloc = (getBestFSource())->getLocation();

  FoodSource * gbestneighbour = getSuitableReferencefor(currentFood, index);
  double * gbestdistloc = gbestneighbour->getLocation();

  
  double value = 0;
  
  double randlr= -1.0;
  double randhr= 1.0;
  
  if(!config->isDefaultUniformRE3()){
      randlr= -1.0*config->getRandRange3e();
      randhr= config->getRandRange3e();
  }

  switch(config->FourthTermStrategyEmp()){
    case GBEST_CURRENT: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-currloc[p2c]); break;
    case GBEST_RANDOM: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-neighbourloc[p2c]); break;
    case CURRENT_RANDOM: value = RNG::randVal(randlr,randhr)*(currloc[p2c]-neighbourloc[p2c]); break;
    case RANDOM_RANDOM: value = RNG::randVal(randlr,randhr)*(neighbourloc[p2c]-neighbour2loc[p2c]); break;
    case CURRENT_GBESTDIST: value = RNG::randVal(randlr,randhr)*(currloc[p2c]- gbestdistloc[p2c]); break;
    case NO_STRATEGY: value = 0; break;
  }
  
  return value;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

double ABCX::getFirstTermOnl(int index, int p2c){
  FoodSource * currentFood = foodSources.at(index);
  double * currloc = currentFood->getLocation();
  /*A randomly chosen solution is used in producing a mutant solution of the solution i*/ 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  double * neighbourloc = (foodSources.at(neighbour))->getLocation();

  double * gbestloc = (getBestFSource())->getLocation();
  
  double value = 0;
  switch(config->FirstTermStrategyOnl()){
    case CURRENTLOC: value = currloc[p2c]; break;
    case RANDOMLOC: value = neighbourloc[p2c]; break;
    case GBESTLOC: value = gbestloc[p2c]; break;
  }
  
  return value;
}


double ABCX::getSecondTermOnl(int index, int p2c){
  FoodSource * currentFood = foodSources.at(index);
  double * currloc = currentFood->getLocation();
  /*A randomly chosen solution is used in producing a mutant solution of the solution i*/ 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  int neighbour2 = -1;
  do{
      neighbour2= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour2 == index || neighbour2 == neighbour);

  double * neighbourloc = (foodSources.at(neighbour))->getLocation();
  double * neighbour2loc = (foodSources.at(neighbour2))->getLocation();
  
  double * gbestloc = (getBestFSource())->getLocation();
  
  FoodSource * gbestneighbour = getSuitableReferencefor(currentFood, index);
  double * gbestdistloc = gbestneighbour->getLocation();
  
  double value = 0;
  double randlr= -1.0;
  double randhr= 1.0;
  
  if(!config->isDefaultUniformRO1()){
      randlr= -1.0*config->getRandRange1o();
      randhr= config->getRandRange1o();
  }

  switch(config->SecondTermStrategyOnl()){
    case GBEST_CURRENT: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-currloc[p2c]); break;
    case GBEST_RANDOM: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-neighbourloc[p2c]); break;
    case CURRENT_RANDOM: value = RNG::randVal(randlr,randhr)*(currloc[p2c]-neighbourloc[p2c]); break;
    case RANDOM_RANDOM: value = RNG::randVal(randlr,randhr)*(neighbourloc[p2c]-neighbour2loc[p2c]); break;
    case CURRENT_GBESTDIST: value = RNG::randVal(randlr,randhr)*(currloc[p2c]- gbestdistloc[p2c]); break;
    case NO_STRATEGY: value = 0; break;
  }
  
  return value;
 
}
      
double ABCX::getThirdTermOnl(int index, int p2c){
   FoodSource * currentFood = foodSources.at(index);
  double * currloc = currentFood->getLocation();
  /*A randomly chosen solution is used in producing a mutant solution of the solution i*/ 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  int neighbour2 = -1;
  do{
      neighbour2= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour2 == index || neighbour2 == neighbour);

  double * neighbourloc = (foodSources.at(neighbour))->getLocation();
  double * neighbour2loc = (foodSources.at(neighbour2))->getLocation();
  
  double * gbestloc = (getBestFSource())->getLocation();
  
  FoodSource * gbestneighbour = getSuitableReferencefor(currentFood, index);
  double * gbestdistloc = gbestneighbour->getLocation();
  
  double value = 0;
  double randlr= -1.0;
  double randhr= 1.0;
  
  if(!config->isDefaultUniformRO2()){
      randlr= -1.0*config->getRandRange2o();
      randhr= config->getRandRange2o();
  }
  
  switch(config->ThirdTermStrategyOnl()){
    case GBEST_CURRENT: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-currloc[p2c]); break;
    case GBEST_RANDOM: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-neighbourloc[p2c]); break;
    case CURRENT_RANDOM: value = RNG::randVal(randlr,randhr)*(currloc[p2c]-neighbourloc[p2c]); break;
    case RANDOM_RANDOM: value = RNG::randVal(randlr,randhr)*(neighbourloc[p2c]-neighbour2loc[p2c]); break;
    case CURRENT_GBESTDIST: value = RNG::randVal(randlr,randhr)*(currloc[p2c]- gbestdistloc[p2c]); break;
    case NO_STRATEGY: value = 0; break;
  }
  
  return value;
}
      
      
double ABCX::getFourthTermOnl(int index, int p2c){
   FoodSource * currentFood = foodSources.at(index);
  double * currloc = currentFood->getLocation();
  /*A randomly chosen solution is used in producing a mutant solution of the solution i*/ 
  int neighbour = -1;
  do{
      neighbour= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour == index);
  
  int neighbour2 = -1;
  do{
      neighbour2= floor (RNG::randVal(0,foodSources.size())); 
  }while(neighbour2 == index || neighbour2 == neighbour);

  double * neighbourloc = (foodSources.at(neighbour))->getLocation();
  double * neighbour2loc = (foodSources.at(neighbour2))->getLocation();
  
  double * gbestloc = (getBestFSource())->getLocation();
  
  FoodSource * gbestneighbour = getSuitableReferencefor(currentFood, index);
  double * gbestdistloc = gbestneighbour->getLocation();
  
  double value = 0;
  double randlr= -1.0;
  double randhr= 1.0;
  
  if(!config->isDefaultUniformRO3()){
      randlr= -1.0*config->getRandRange3o();
      randhr= config->getRandRange3o();
  }  

  switch(config->FourthTermStrategyOnl()){
    case GBEST_CURRENT: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-currloc[p2c]); break;
    case GBEST_RANDOM: value = RNG::randVal(randlr,randhr)*(gbestloc[p2c]-neighbourloc[p2c]); break;
    case CURRENT_RANDOM: value = RNG::randVal(randlr,randhr)*(currloc[p2c]-neighbourloc[p2c]); break;
    case RANDOM_RANDOM: value = RNG::randVal(randlr,randhr)*(neighbourloc[p2c]-neighbour2loc[p2c]); break;
    case CURRENT_GBESTDIST: value = RNG::randVal(randlr,randhr)*(currloc[p2c]- gbestdistloc[p2c]); break;
    case NO_STRATEGY: value = 0; break;
  }
  
  return value;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*****************************************************************************************************************
 * Employed bee asamasinin isletildigi metod
 * 
 * ***************************************************************************************************************/
void ABCX::sendEmployedBees(){

      int i,j; 
      
      for (i=0;i<foodSources.size();i++) { // Her bir yiyecek kaynagi icin

	  FoodSource * currentFood = foodSources.at(i); // siradaki yiyecek kaynagina git
	  double * currloc = currentFood->getLocation(); 
	  
	  for(j=0;j<config->getProblemDimension();j++) // yiyecek kaynaginin pozisyonunu gecici bir yere ata
	      tempSource[j]= currloc[j]; 
	  
	  // kac tane boyutta degisiklik yapilacaksa o kadar adet islemi tekrarla
	  for(int m=0; m < config->getMRE(); m++){
	      // degistirilecek boyutu al
	      int param2change= floor (RNG::randVal(0,config->getProblemDimension())); 

	      // 4 terimli arama islemimizden gecirerek boyutun degerini degistir
	      tempSource[param2change]= getFirstTermEmp(i,param2change)+getSecondTermEmp(i,param2change)+getThirdTermEmp(i,param2change)+getFourthTermEmp(i,param2change);//currloc[param2change]+(currloc[param2change]-neighbourloc[param2change])*(r-0.5)*2; 
	 
	  
	      // eger boyutun degeri sinirlari tasiriyorsa, sinirlar icine cek 
	      if (tempSource[param2change] < config->getMinInitRange()) 
		  tempSource[param2change] = config->getMinInitRange(); 
	      if (tempSource[param2change] > config->getMaxInitRange()) 
		  tempSource[param2change] = config->getMaxInitRange(); 
	      
	  }
	  
	  // guncellenen degerle yiyecek kaynagini sina. Yani amac fonksiyonuna sokarar amac degerini elde et
	  long double objectiveValue=p->getFunctionValue(tempSource); 
	  
	    
	  // eger elde edilen degerin fitnes degeri daha iyiyse pozisyonu guncelle
	  if (1.0/ (objectiveValue+1.0) > currentFood->getFitness()) { 
	    
	      currentFood->initTrail(); // trial degiskenini sifirla
	      currentFood->setLocation(tempSource); // yiyecek kaynaginin pozisyonunu guncelle
	      currentFood->setObjectiveValue(objectiveValue); // amac degerini guncelle
	  } 
	  else {  //eger elde edilen degerin fitnessi kucukse iyilestirme yapamamis demektir, trial degerini artir 
	      currentFood->increaseTrailVal();
	  } 

      } 
      /*end of employed bee phase*/ 

}



////////////////////////////////////////////////////////////// CALCULATE PROBABILITIES //////////////////////////////////////////////////////////////////////////////
/**********************************************************************************************************************
 * Bu metod onlooker bee asamasinda secilecek yiyecek kaynaklarinin secilme olasiginin belirlendigi metoddur.
 * Literaturdeki 3 farkli secim yolu denenmistir. Strateji disaridan alinan bilgiye gore secilmektedir.
 * ********************************************************************************************************************/
void ABCX::calculateProbabilities(){
  switch(config->probabilityCalcType()){
    case DEFAULT_PROBCALC: calculateProbabilitiesDefault(); break;
    case WEIGHTED_PROBCALC: calculateProbabilitiesWeighted(); break;
    case ORDERED_PROBCALC: calculateProbabilitiesOrdered(); break;
  }
  
}

/*******************************************************************************************************************
 * Orjinal ABC'deki olasilik hesabi yontemidir. Makalemde Eq. 4 'de nasil hesaplandigi gosterilmistir. 
 * Bu hesaplamanin dezavantaji, bir yiyecek kaynagi digerlerinden cok cok iyi durumdaysa olasiligi cok yuksek ve
 * digerlerinin cok az olacagindan secimde cesitliligin azalmasina sebeb olmasidir. Bu durum ozellikle yerel arama
 * kullanildiginda ortaya cikabilir.
 *******************************************************************************************************************/
void ABCX::calculateProbabilitiesDefault(){
      int i; 
      double totalfit = 0.0; 
  
      for (i=0;i<foodSources.size();i++) { 
	   totalfit += (foodSources.at(i))->getFitness(); 
      } 

      for (i=0;i<foodSources.size();i++) { 
	  (foodSources.at(i))->setProbability( (foodSources.at(i))->getFitness() / totalfit ); 
      } 


}

/*******************************************************************************************************************
 * Agirlikli olasilik hesaplama metodudur. Bu metod orjinal ABC'de bahsedilmese de orjinal ABC kodunda yer alan 
 * bir yontemdir. Bu yontem ile en kotu yiyecek kaynaklarinin dahi en az %10 bir secim olasiligi garanti edilmis olur.
 * pi = 0.9 - (0.9*(fitness(i)/maxfit))+0.1
 * *****************************************************************************************************************/
void ABCX::calculateProbabilitiesWeighted(){
      int i; 
      double maxfit; 
      maxfit=(foodSources.at(0))->getObjectiveValue(); 
  
      for (i=1;i<foodSources.size();i++) { 
	    if ((foodSources.at(i))->getObjectiveValue() > maxfit) 
		maxfit= (foodSources.at(i))->getObjectiveValue(); 
      } 

      for (i=0;i<foodSources.size();i++) { 
	  (foodSources.at(i))->setProbability( (0.9 - (0.9*((foodSources.at(i))->getObjectiveValue()/maxfit))) + 0.1 ); 
      } 


}

/*********************************************************************************************************************
 * Silamadaki yerlerine olasilik belirleyen bir yaklasimdir. Bence en iyi yontem. Cunku fitness degerinin kendisinden
 * ziyade sıralayip siradaki yeri baz alindigindan cok aykiri farkliliklar olsa da bunlar kendini gostermemis olacagindan
 * hemen hemen her yiyecek kaynagi belli bir olcude secilme olasiligina sahip oluyor. Rosenbrock ABC'de tanimlanmistir.
 * *******************************************************************************************************************/
void ABCX::calculateProbabilitiesOrdered(){
      int i; 
      double totalfit = 0.0; 
  
      int * ord = getOrder();
      
      for (i=0;i<foodSources.size();i++) { 
	   totalfit += (foodSources.at(i))->getFitness(config->getSP(), ord[i], foodSources.size()); 
      } 

      for (i=0;i<foodSources.size();i++) { 
	  (foodSources.at(i))->setProbability( (foodSources.at(i))->getFitness(config->getSP(), ord[i], foodSources.size()) / totalfit ); 
      } 

      delete [] ord;
}


int * ABCX::getOrder()
{
	int i,j;
	int * order = new int[foodSources.size()];

	for(i=0;i<foodSources.size();i++)
	{
		order[i]=1;
		for(j=0;j<foodSources.size();j++){
		  if((foodSources.at(i))->getObjectiveValue()<(foodSources.at(j))->getObjectiveValue())
		    order[i]=order[i]+1;
		}
	}
	
	return order;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////// ONLOOKER BEES //////////////////////////////////////////////////////////////////////////////////////

/***********************************************************************************************************************************
 * Onlooker bee asamasinin isletildigi bolumdur. Bu asamanin employed bee asamasindan tek farki, ziyaret edilen yani degisiklige 
 * ugrayan yiyecek kaynaginin olasiliga göre secilmesidir. Her bir yiyecegin ziyaret edilme olasiligi bir onceki metodlarda belirleniyordu
 * 
 * *********************************************************************************************************************************/
void ABCX::sendOnlookerBees(){
    
    int i,j,t; 
    i=0; 
    t=0; 
    /*onlooker Bee Phase*/ 
    while(t < foodSources.size()) { 
	  FoodSource * currentFood = foodSources.at(i);
    
	  double r = RNG::randVal(0,1);
	  
	  if(r < currentFood->getProbability()) {          
	  
	    t++; 
	    
	    int param2change= floor (RNG::randVal(0,config->getProblemDimension())); 
	    

	    double * currloc = currentFood->getLocation();
	    for(j=0;j<config->getProblemDimension();j++) 
		tempSource[j]= currloc[j]; 
	  
	    for(int m=0; m < config->getMRO(); m++){
		/*The parameter to be changed is determined randomly*/ 
		int param2change= floor (RNG::randVal(0,config->getProblemDimension())); 
		tempSource[param2change]= getFirstTermOnl(i,param2change)+getSecondTermOnl(i,param2change)+getThirdTermOnl(i,param2change)+getFourthTermOnl(i,param2change);
	    
		/*if generated parameter value is out of boundaries, it is shifted onto the boundaries*/ 
		if (tempSource[param2change] < config->getMinInitRange()) 
		    tempSource[param2change] = config->getMinInitRange(); 
		if (tempSource[param2change] > config->getMaxInitRange()) 
		    tempSource[param2change] = config->getMaxInitRange(); 
	    }
	    
	    long double objectiveValue=p->getFunctionValue(tempSource); 
	    
	      
	    /*a greedy selection is applied between the current solution i and its mutant*/ 
	    if (1.0/ (objectiveValue+1.0) > currentFood->getFitness()) { 
	      
		/*If the mutant solution is better than the current solution i, replace the solution with the mutant and reset the trial counter of solution i*/ 
		currentFood->initTrail();
		currentFood->setLocation(tempSource);
		currentFood->setObjectiveValue(objectiveValue);
	    } 
	    else {   /*if the solution i can not be improved, increase its trial counter*/ 
		currentFood->increaseTrailVal();
	    } 
	  	     
	  } /*if */ 
	  
	  i++; 
	  if (i == foodSources.size()-1) 
	    i=0; 
      }/*while*/ 
      /*end of onlooker bee phase     */ 

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////// SCOUT BEE STEP //////////////////////////////

/*************************************************************************************************************
 * Scout bee asamasinin isletildigi metoddur. 5 tane farkli scout bee asamasi yontemi burada istenildiginde 
 * secilebilmektedir. 
 * ***********************************************************************************************************/
void ABCX::sendScoutBees(){
    switch(config->scoutBeeStrategy()){
      case DEFAULT_SCOUT: sendScoutBeesDefault(); break;
      case BABC_SCOUT: sendScoutBeesBABC(); break;
      case CABC_SCOUT: sendScoutBeesCABC(); break;
      case IABC_SCOUT: sendScoutBeesIABC(); break;
      case ERABC_SCOUT: sendScoutBeesERABC(); break;
    }
}


/**************************************************************************************************************
 * Original ABC'deki scout bee mekanizma
 **************************************************************************************************************/
void ABCX::sendScoutBeesDefault(){
      int maxtrialindex,i; 
      maxtrialindex=0; 
      for (i = 1; i < foodSources.size(); i++) { // bir yiyecek kaynaginin limite gelip gelmedigini kontrol et
	  if ((foodSources.at(i))->getTrail() > (foodSources.at(maxtrialindex))->getTrail()) {
	      maxtrialindex=i;
	  }
      } 
      if( (foodSources.at(maxtrialindex))->getTrail() >= config->getLimit()) 
      { 
	      (foodSources.at(maxtrialindex))->reInit(); // limit degerine ulasan yiyecek kaynagini bastan olustur
      }

}


/*******************************************************************************************************************
 * Best-so-far selection ABC'deki (BABC) scout bee asamasi
 * 
 * Bu yontemde limite ulasan yiyecek kaynaklari tekrar olusturulurken iterasyon sayısına göre daralan bir yontem ile
 * yerlestirilmektedir.
 */
void ABCX::sendScoutBeesBABC(){
      int i; 
      for (i = 0; i < foodSources.size(); i++) { 
	  if( (foodSources.at(i))->getTrail() >= config->getLimit()) {
	      reinitFSourceBABC(foodSources.at(i));
	  }
      } 
}

/********************************************************************************************************************
 * BABC'deki scout bee asamasinin her bir scout bee icin uygulanan kismi
 * fsource: tekrardan olusturlacak olan yiyecek kaynagi
 ********************************************************************************************************************/
void ABCX::reinitFSourceBABC(FoodSource * fsource){
      double wMax = config->getWMax(); 
      double wMin = config->getWMin();
      double currEvals = (double)p->getFunctionEvaluations();
      double maxEvals = (double)config->getMaxFES();
  
      double * floc = fsource->getLocation();
      for(unsigned int i=0;i<config->getProblemDimension();i++) 
	  tempSource[i]= floc[i]; 

      //update position of scout bees
      for(unsigned int i=0;i<config->getProblemDimension();i++){
	  double r = RNG::randVal(0,1);
	  // BABC de tanimli formul: vij = xij + xij*U(-1,1)*(wMax-(currItr/maxItr)*(wMax-wMin))
	  tempSource[i]= floc[i] + (wMax - ((double)currEvals / (double)maxEvals)*(wMax-wMin)) * (floc[i])*(r-0.5)*2; 
	  if (tempSource[i] < config->getMinInitRange()) 
	      tempSource[i] = config->getMinInitRange(); 
	  if (tempSource[i] > config->getMaxInitRange()) 
	      tempSource[i] = config->getMaxInitRange(); 
      
      }
      
      long double objectiveValue=p->getFunctionValue(tempSource); 
      
	
      /*a greedy selection is applied between the current solution i and its mutant*/ 
      if (objectiveValue < fsource->getObjectiveValue()) { 
	
	  /*If the mutant solution is better than the current solution i, replace the solution with the mutant and reset the trial counter of solution i*/ 
	  fsource->initTrail();
	  fsource->setLocation(tempSource);
	  fsource->setObjectiveValue(objectiveValue);
      } 
      else {   /*if the solution i can not be improved, increase its trial counter*/ 
	  fsource->increaseTrailVal();
      } 

      
}


/**
 * Chaotic ABC'deki scout bee mekanizması: Limit/2 ye gelince chaotic search yapıyor kendileri
 */
void ABCX::sendScoutBeesCABC(){
      int i; 
      for (i = 0; i < foodSources.size(); i++) { 
	  if( (foodSources.at(i))->getTrail() >= config->getLimit() / 2) 
	  { 
	      chaoticSearchCABC(foodSources.at(i));
	  }
	  if( (foodSources.at(i))->getTrail() >= config->getLimit()) 
	  { 
	      (foodSources.at(i))->reInit(); 
	  }
      } 
      
}


/**
 * CABC'nin chaotic search algoritması
 */
void ABCX::chaoticSearchCABC(FoodSource * fsource){
    
    int param2change= floor (RNG::randVal(0,config->getProblemDimension())); 
    //double ch = 0.0;
    int t = 0;
    double ch = RNG::randVal(0,1);
    double prev = RNG::randVal(0,1); 
    double temp = prev;
    
    do{
	for (unsigned k = 0; k < config->getK(); k++){ // K iterasyon boyunca kaotik deger olustur. Kaotik map disaridan giriliyor
	    switch(config->getChaoticMapID()){ // kaotik map i sec ve islet
	      case LOGISTIC:
		ch = ChaoticMaps::Logistic(ch);
		break;
	      case CIRCLE:
		ch = ChaoticMaps::Circle(ch);
		break;
	      case GAUSS:
		ch = ChaoticMaps::Gauss(ch);
		break;
	      case SINUSOIDAL:
		ch = ChaoticMaps::Sinusoidal(ch);
		break;
	      case SINUS:
		ch = ChaoticMaps::Sinus(ch);
		break;
	      case TEND:
		ch = ChaoticMaps::Tent(ch);
		break;
	      case HENON:
		prev=ch;
		ch = ChaoticMaps::Henon(ch,temp);
		break;
	      case ACFUNC:
		ch = ChaoticMaps::ACFunc(ch,config->getMu());
		break;
	    }
	}
	
	
	double * currloc = fsource->getLocation();
	for(int j=0;j<config->getProblemDimension();j++) 
	    tempSource[j]= currloc[j]; 

	
//	double r = RNG::randVal(0,1);
	//dikkat burada artik r yerine ch degiskeni yani rasgele sayi ureteci kullaniliyor
	tempSource[param2change]= currloc[param2change] + ((config->getMaxInitRange()-config->getMinInitRange()) / 2.0) * (2.0 * ch - 1);

	/*if generated parameter value is out of boundaries, it is shifted onto the boundaries*/ 
	if (tempSource[param2change] < config->getMinInitRange()) 
	    tempSource[param2change] = config->getMinInitRange(); 
	if (tempSource[param2change] > config->getMaxInitRange()) 
	    tempSource[param2change] = config->getMaxInitRange(); 

	long double objectiveValue=p->getFunctionValue(tempSource); 
	
	  
	/*a greedy selection is applied between the current solution i and its mutant*/ 
	if (1.0/ (objectiveValue+1.0) > fsource->getFitness()) { 
	    fsource->setLocation(tempSource);
	    fsource->setObjectiveValue(objectiveValue);
	    while (param2change = floor (RNG::randVal(0,config->getProblemDimension())) == param2change);
	} 
        fsource->increaseTrailVal();
	t++;
    }while(t < config->getLimit() / 2);
}

/***************************************************************************************************************************
 * IABC'deki yani benim bir tarafimdan uydurdugun scout bee yontemi. Bu yontemde yiyecek kaynagi konumlandirilirken 
 * en iyi yiyecek kaynaginin yakinlarinda bir yere yerlestiriliyor. Ne kadar yakinina yerlestirilecegine ShakingFactor 
 * degiskeni ile karar veriyoruz.
 * *************************************************************************************************************************/
void ABCX::sendScoutBeesIABC(){
      int maxtrialindex,i; 
      maxtrialindex=0; 
      for (i = 1; i < foodSources.size(); i++) { /* check if food source exceed its trail limit and take its index if any */
	  if ((foodSources.at(i))->getTrail() > (foodSources.at(maxtrialindex))->getTrail()) {
	      maxtrialindex=i; 
	  }
      } 
      if( (foodSources.at(maxtrialindex))->getTrail() >= config->getLimit()) 
      { 
	      (foodSources.at(maxtrialindex))->reInit(config->getShakingFactor(), p->getBestSoFarSolution());
      }

}

/*****************************************************************************************************************************
 * Efficient and Robust ABC (ERABC) deki yontemdir. Bu yontem direk olarak kaotik arama ile scout bee asamasini yapiyor.
 * Pseudo-code algoritmanin makalesinde bulunabilir. Oradan aynen implemente ettim.
 * 
 * ***************************************************************************************************************************/
void ABCX::sendScoutBeesERABC(){
      int i; 
      for (i = 0; i < foodSources.size(); i++) { 
	  if( (foodSources.at(i))->getTrail() >= config->getLimit()) 
	  { 
	      chaoticSearchERABC(foodSources.at(i));
	  }
      } 
      
}


void ABCX::chaoticSearchERABC(FoodSource * fsource){
    
	double cx[config->getProblemDimension()];
	double * currloc = fsource->getLocation();
	for(int j=0;j<config->getProblemDimension();j++){ 
	    tempSource[j]= currloc[j];
	    cx[j] = (currloc[j]-config->getMinInitRange()) / (config->getMaxInitRange()-config->getMinInitRange());
	}
	
	for (int k = 0; k < 300; k++){
	  for(int j=0;j<config->getProblemDimension();j++){ 
	    // attaki islem bu aramada kullanilan kaotik map fonksiyonudur.
	    cx[j] = 4 * cx[j] * (config->getMaxInitRange()-config->getMinInitRange());
	    
	    tempSource[j] = config->getMinInitRange() + cx[j] * (config->getMaxInitRange()-config->getMinInitRange());
	    
	    if (tempSource[j] < config->getMinInitRange() || tempSource[j] > config->getMaxInitRange()) 
	      tempSource[j] = config->getMinInitRange() + RNG::randVal(0,1)* (config->getMaxInitRange()-config->getMinInitRange());
	    
	  }
	  
	  long double objectiveValue=p->getFunctionValue(tempSource); 
	
	  
	  /*a greedy selection is applied between the current solution i and its mutant*/ 
	  if (1.0/ (objectiveValue+1.0) > fsource->getFitness()) { 
	      fsource->setLocation(tempSource);
	      fsource->setObjectiveValue(objectiveValue);
	      fsource->initTrail();
	      return;
	  } 
	  else
	      fsource->increaseTrailVal();
	  
	}
	
}

void ABCX::adaptivelySelectLS(FoodSource* bestf){
  
  LocalSearch* mtsls = new Mtsls1(config, p);
  LocalSearch*  cmaes= new ICMAESLS(config, p);
  
  if (ls != NULL) delete ls;

  long double currsol = p->getBestSolutionValue();
  
  FoodSource* f1 = NULL;
  FoodSource* f2 = NULL;
  
  if(!nols){
      f1 = new FoodSource(bestf);
      f2 = new FoodSource(bestf);
  }else {
    f1 = new FoodSource(config, p);
    f2 = new FoodSource(f1);
  }
  
  mtsls->apply(f1, (config->getMaxInitBound()-config->getMinInitBound())/4, config->getMaxFES()*config->trainingRatio());
  long double solutionmtsls = p->getBestSolutionValue();
  //delete f1;

  //FoodSource* f2 = new FoodSource(bestf);
  cmaes->apply(f1, (config->getMaxInitBound()-config->getMinInitBound())/4, config->getMaxFES()*config->trainingRatio());
  long double solutioncmaes = p->getBestSolutionValue();
  delete f2;
  delete f1;
  if(currsol != solutioncmaes || currsol != solutionmtsls){
      if(solutioncmaes < solutionmtsls){
	//cout<<"cmaes"<<endl;
	ls = cmaes;
	delete mtsls;
      }
      else {
	//cout<<"mtsls"<<endl;
	ls = mtsls;
	delete cmaes;
      }
  }else{
	delete cmaes;
	delete mtsls;
	//delete ls;
	//cout<<"uabc"<<endl;
	ls = NULL;
	nols = true;
  }
  
  bestf->setObjectiveValue(p->getBestSolutionValue());
  bestf->setLocation(p->getBestSoFarSolution());

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////7

/********************************************************************************************************************************
 * Algoritmanin isletildiği metoddur.
 * 
 * *******************************************************************************************************************************/
void ABCX::run(){
      unsigned int iterations=0;

      do{

	  sendEmployedBees();

	  calculateProbabilities();

	  sendOnlookerBees();
	  getBestFSource();

	  sendScoutBees();
	  FoodSource * bestfood = getBestFSource(); // en iyi yiyecek kaynagini al ve

	  if(p->getFunctionEvaluations() > (config->getMaxFES()*config->trainingRatio())){
	    if(config->getLocalSearchID() == ADAPTIVE_LS && !nols)
	      adaptivelySelectLS(bestfood);
	  }
	  if(ls != NULL){
		long double solbefore = p->getBestSolutionValue();	    
		applyLocalSearch(bestfood);		    // uzerinde yerel arama algoritmasi uygula (eğer yerel arama secilirse)  
	  	long double solafter = p->getBestSolutionValue();
		if(solbefore > solafter) nols= true;
		else nols = false;
	  }
	  if(config->isPopulationIncremented()) // yiyecek kaynaginin sayisi arttilmak isteniyorsa
	      //eklemek icin istenen periyot geldi ve maksimum populasyon sayisina ulasilmadiysa
	      if(iterations>0 && iterations % config->getGrowthPeriod() == 0 && foodSources.size()<config->getMaximumFoodSize()){
		  foodSources.push_back(new FoodSource(config,p,getBestFSource())); // yiyecek kaynagini en iyi yiyeceğe göre ekle
	  }

	  iterations++;
	  
      }while(notDone());
      if (ls != NULL && config->getLocalSearchID() == ADAPTIVE_LS) delete ls;
      //else cout<<"ls null değil"<<endl;
}

