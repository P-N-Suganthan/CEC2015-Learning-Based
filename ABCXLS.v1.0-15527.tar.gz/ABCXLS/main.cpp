/*
    Copyright 2015 Dogan Aydin and Thomas Stuetzle
    
    Dogan Aydin		<dogan.aydin@dpu.edu.tr>
    Thomas Stuetzle	<stuetzle@ulb.ac.be>

    This file is part of ABC-X-LS.

    ABC-X-LS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    ABC-X-LS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with ABC-X-LS.  If not, see <http://www.gnu.org/licenses/>.
*/

//Configuration
#include "configuration.h"

//Problems
#include "problem.h"

//Algorithms
#include "ABC.h" 
#include "ABCX.h" 

//local Search Algorithms
#include "localSearch.h"
#include "mtsls1.h"
#include "powell.h"
#include "icmaesils.h"
#include "rng.h"

//Timers
#include <sys/time.h>
#include <sys/resource.h>

//C++ Libraries
#include <iostream>


using namespace std;


LocalSearch * initializeLocalSearch(Configuration * config, Problem * p){
	LocalSearch * ls = NULL;
	switch(config->getLocalSearchID()){
	  case MTSLS1: 
	    ls = new Mtsls1(config, p);
	    break;
	  case POWELL:
	    ls = new Powell(config, p);  
	    break;
	  case CMAES:
	    ls = new ICMAESLS(config,p);
	    break;
	}
	
	return ls;
}



int main( int argc, char** argv) {	

	double stime;
	static struct timeval tp;	
	int i;
	LocalSearch * ls;

	//Command line parsing
	Configuration* config = new Configuration(argc,argv);

	//Random number generator
	RNG::initializeRNG(config->getRNGSeed());

    	//Initialize Problem
	Problem* problem = new Problem(config);
	
	//Initialize LocalSearch
	ls = initializeLocalSearch(config, problem);
	
	//Start timer
	gettimeofday( &tp, NULL );
   	stime =(double) tp.tv_sec + (double) tp.tv_usec/1000000.0;
	config->setStartTime(stime);

	//ABC intialization	
	ABC* abc = new ABCX(config, problem, ls);

	//ABC execution
	abc->run();
	cout.precision(20);
	cout<<"solution: "<<scientific<<problem->getBestSolutionValue()<<endl;

	//Memory release
	RNG::deallocateRNG();
	RNG::deallocatePermutation();
//	cout<<"prob"<<endl;
	delete problem;
//		cout<<"abc"<<endl;
	delete abc;
//		cout<<"conf"<<endl;
	delete config;
//		cout<<"ls"<<endl;
	delete ls;
//		cout<<"ok"<<endl;
	return 0;
}
