function fit=cec_test(x,func_num)
global FES fitFES FEScut cutcount bestnow
fit=cec15_func(x,func_num)-func_num*100;
if fit==Inf
    fit=1e+100;
end
FES=FES+1;
if fit<bestnow
    bestnow=fit;
end
if FES>FEScut(cutcount)
    fitFES=[fitFES,bestnow];
    cutcount=cutcount+1;
end
