% clear all
% mex cec15_func.cpp -DWINDOWS
clear all

global FES fitFES FEScut cutcount bestnow % CC1 CC2
Xmin=-100;
Xmax=100;
runs=51;
fitFES=[];
fhd=str2func('cec_test');
D_choose=[10,30,50];
pop_size_choose=[60,100,150];
err=1e-8;
group_num_choose=[10,20,30];
Particle_Number=3;
for dd=1:2
    D=D_choose(dd);
    group_num=group_num_choose(dd);
    pop_size=pop_size_choose(dd);
    Max_FES=D*10000;
    FEScut=[0.0001, 0.001, 0.01, 0.02, 0.03, 0.04,0.05, 0.1, 0.2, 0.3,0.4,0.5,0.6,0.7,0.8,0.9, 1.0,Inf].*Max_FES;
    iter_max=floor(Max_FES/pop_size);
    Table=[];xbest=[];fbest=[];
    func_num=1;
%     for i=func_num:func_num
    for i=1:15
        func_num=i;
        fit_FES_rec=[];
        for j=1:runs
            i,j,
            FES=0;cutcount=1;fitFES=[];bestnow=Inf;
            [gbest,gbestval,fitcount,fit_cut,get_flag]= DMS_PSO_func(fhd,1e-8,0,Max_FES,group_num,Particle_Number,D,Xmin,Xmax,Xmin,Xmax,func_num);
            if gbestval<err
                gbestval=0;
            end
            xbest(j,:)=gbest;
            fbest(i,j)=gbestval;
            fitFES(find(fitFES<err))=0;
            if length(fitFES)<17&fitcount>=Max_FES
                fitFES((length(fitFES)+1):17)=0;
            end
            if fitcount<Max_FES
                fitFES(17)=gbestval;
            end
            fit_FES_rec=[fit_FES_rec;fitFES];
        end
        f_mean(i)=mean(fbest(i,:));
        tmp=[min(fbest(i,:)),max(fbest(i,:)),median(fbest(i,:)),mean(fbest(i,:)),std(fbest(i,:))];
        Table=[Table;tmp];
        eval(['save output_data/DMSPSO_results_' num2str(D) 'D_0111 xbest fbest Table' ]);
        eval(['save output_data/DMSPSO_Table_' num2str(D) 'D_0111.txt Table -ASCII -DOUBLE']);
%         eval(['save output_data/DMSPSO_CC_' num2str(D) 'D_0111 CC1 CC2 ']);
        eval(['save output_data/DMSPSO_' num2str(func_num) '_' num2str(D) '.txt fit_FES_rec -ASCII -DOUBLE']);
    end
end


