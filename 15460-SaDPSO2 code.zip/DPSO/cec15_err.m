function err= cec15_err(x,fun)
f=cec15_func(x,fun);
err=f-fun*100;